# Introduction
Xray-BDD test integration is a standalone tool to update XrayTest execution status in JIRA by reading the execution result from test report. 
It also has the ability to sync XRay test cases with BDD test cases.

##Xray keywords in Feature File 
**TestComponentAnnotation:** Each E2E test feature file must have a component annotation declared as it is a mandatory
                           parameter to create XrayTest.TestComponent must be specified before 'Feature' keyword.
                           e.g., @TestComponent=xray-karate-poc (where  xray-karate-poc is the component name from JIRA).
                             
**Background Section     :** It is considered as Pre-Condition for Xray Tests. Pre-Condition has 1:n relation ship with the 
                           test scenarios inside the feature file.
                           Background-Xray pre-condition mapping should be specified as  #@PRECOND_{Xray Pre Condition Number}.
                           e.g., #@PRECOND_PORT-11207
                           Pre condition should be placed next line to 'Background' section.
                           
**Scenario Section       :** Each E2E scenario should have @TEST annotation to associate with XRayTest.
                           Test Annotation Format: @TEST_{Xray test number}.
                           e.g., @TEST_PORT-11207
                           TEST annotation should be declared in a separate line.Additional scenario annotations can be 
                           specified in a new line, additional annotations are updated as Xray test labels.                                 

## Execution Detasils
* Path: xray/main
* Command to Execute: node {Main-FileName-ToExecute} {Module-Directory Name within the project ex:claimsolutions}
{right now a demo feature file has been created within claimsolutions module}

### Main Executable Files
#### mainXrayCucumberScenarioSync.js (To be executed from local machine)

      Pre-Requisite: All E2E feature file must have test component annotation declared.
      
      Script to create/Sync XRay test cases in JIRA. Script collects all scenarios within feature file directry specified, 
      it then creates a Xray test in JIRA provided test case annotation is not specified.If test case annotation present
      for a scenario then the test get(s) updated.
      
      Manual Process after the script has been executed:
       1. User has to manually associate the scenario and precondition(if applicable) within feature file.
       2. User has to update TestSet informarion in Xray test JIRA.
      Details of created JIRA can be found in script log.
      
      Note: This step is optional.If users creates Xray tests manually then they simply need to associate pre-condition
      and test annotation manually.
                     
#### mainXrayCucumberScenarioSync.js (To be executed from local/TC)

     Pre-Requisites: 
           1. All E2E feature file must have test component annotation declared.
           2. All E2E scenarios and background section should have required XRay-JIRA mappings.
           
     Script to update the test execution status of associated test cases and pre-conditions, it also updates
     test description/summary and any additional annotations as labels.
     Script creates Xray test or Xray pre-condition if it does not find @TEST or @PRECOND annotation for a scenario.
     User has to manually update the test execution status after new Xray JIRA item has been created.         

#### mainJiraAddComponentForCucumberTests.js (To be executed from local/TC)
     Pre-Requisites: 
           1. All E2E feature file must have test component annotation declared.
           2. All E2E scenarios and background section should have required XRay-JIRA mappings.
           
     Script to update componet section of Xray tests.