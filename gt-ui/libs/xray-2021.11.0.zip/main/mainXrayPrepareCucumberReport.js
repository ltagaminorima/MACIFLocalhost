global.projectId = process.argv.slice(2)[0];
global.featureDir = process.argv.slice(2)[1];
global.targetDir = process.argv.slice(2)[2];
const importXrayTests = require("./../importXrayTests.js"),
    importExecutionResults = require("./../importExecutionResults.js"),
    cucumberFeaturesDir = "../../../" + global.featureDir,
    cucumberResultsDir = "../../../" + global.targetDir,
    mergedReport = "../cucumber_report.json";

// import the cucumber test into jira to sync them with any xray tests create prior to implementation
importXrayTests.importCucumberTestsToJira(cucumberFeaturesDir).then(function () {
  // combine each result json returned after running cucumber test suite into one cucumber report json file
  importExecutionResults.combineJSONFiles(cucumberResultsDir, mergedReport).then(function () {

  }).catch(function (e) { process.exit(1); });
}).catch(function(e){ process.exit(1); });
