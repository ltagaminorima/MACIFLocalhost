global.filterId = process.argv.slice(2)[0];
const exportXrayTests = require("./../exportXrayTests.js"),
      cucumberFeaturesDir = "../../../" + global.featureDir;

// exports cucumber tests from jira to cucumberfiles folder
exportXrayTests.exportCucumberTestsFromJira().then(function () {
}).catch(function(e){ process.exit(1); });
