var fs = require('fs');
var callerId = require('caller-id');

/**
 * Utility method to log http errors meaningfully
 * By default logs the whole error object to rootDir/debug.log.
 * Log includes caller method name.
 * @param err       Error Object
 */
async function logHttpError(err) {
    var caller = callerId.getData();
    try{
        if(err.hasOwnProperty('response')){
            let response = err.response;
            console.error('Response Status: ' + response.status + ' ' + response.statusText);
            if(response.hasOwnProperty('data')){
                console.error('Response Data: ' + response.data.toString());
            }else {
                console.error(response);
            }
        }else{
            console.error(err);
        }
        fs.appendFileSync("../../debug-xray.log",JSON.stringify(caller, null , 1) + "\n" + JSON.stringify(err, null , 1), 'utf8');
        return;
    }catch(err){
        console.error('Error Processing Http log');
        console.error(err);
    }
};



module.exports = {
    logHttpError
};



